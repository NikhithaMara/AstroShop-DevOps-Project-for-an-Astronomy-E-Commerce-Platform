# Developer - DevOps Collaboration in understanding build steps

- Video of the lecture on udemy is self explanatory. No additional notes is required.